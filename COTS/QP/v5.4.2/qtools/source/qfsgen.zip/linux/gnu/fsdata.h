/* This file has been generatedwith the qfsgen utility. */

#define FS_ROOT (struct fsdata_file *)0

#define FS_NUMFILES 0
