#ifndef CPPUNITTEST_TOOLSSUITE_H
#define CPPUNITTEST_TOOLSSUITE_H

#include <cppunit/Portability.h>
#include <string>

inline std::string toolsSuiteName()
{
  return "Tools";
}

#endif // CPPUNITTEST_TOOLSSUITE_H
