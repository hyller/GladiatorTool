#ifndef FAILUREEXCEPTION_H
#define FAILUREEXCEPTION_H


class FailureException
{
};


#endif  // FAILUREEXCEPTION_H
